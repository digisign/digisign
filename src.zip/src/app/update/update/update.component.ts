import { Component, OnInit } from '@angular/core';
import {Http,Response,Headers} from '@angular/http';
import {ActivatedRoute} from '@angular/router';
import {Router} from '@angular/router';
import 'rxjs/add/operator/toPromise';
@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.css']
})
export class UpdateComponent implements OnInit {
 /* id:number;
  data:object={};
  user=[];
  userobj:object={};
  private headers=new Headers({'content-type':'application/json'})

  constructor(private router:Router,private route:ActivatedRoute,private http:Http) { }
  updatUser(user)*/
 

  ngOnInit() {
  }

}
